## XLR8 Chainlink External Adapter

Based off of code from thodges-gh/CL-EA-NodeJS-Template (I love you Patrick Collins)
`https://github.com/thodges-gh/CL-EA-NodeJS-Template`
Author: @JJZFIVE

#### Steps

1. Install dependencies with `yarn`
1. Run with `yarn start`
1. Call with `curl -X POST -H "content-type:application/json" "http://localhost:8080/" --data '{ "id": 0, "data": { "model": 1, "wrap": 2, "engine": 3 } }'`

#### Deployment

Info on how to deploy with Docker is listed on the GitHub shown above
